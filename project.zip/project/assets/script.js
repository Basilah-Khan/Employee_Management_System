var base_url = 'http://localhost/project/';

$(document).ready(function(){
  activeEmp();
  archivedEmp();
});

function activeEmp(){
  	$('#active_emp_table').DataTable({
        'responsive': true,
        "order": [
            [2, 'desc']
        ],
	    "columnDefs": [
	        { "orderable": false, "targets": [0, 1, 3, 4, 5, 6] }
	    ],
        'language': {
        	'searchPlaceholder': "Emp. Code / Name",
            'paginate': {
                'previous': "<i class='mdi mdi-chevron-left'>",
                'next': "<i class='mdi mdi-chevron-right'>"
            }
        },
        "drawCallback": function () {
            $('.dataTables_paginate > .pagination').addClass('pagination-rounded');
        },
        'processing': true,
        'serverSide': true,
        ajax: {
            'url': base_url + 'main.php?action=active_employee', 
            'type': 'POST',
            'data': ''
        },
        'columns': [
            { data: 'srno' },
            { data: 'emp_code' },
            { data: 'date' },
            { data: 'name' },
            { data: 'phone' },
            { data: 'email' },
            { data: 'action' },
        ],
        "bDestroy": true
    });
}

function archivedEmp(){
  	$('#archived_emp_table').DataTable({
        'responsive': false,
        'scroll': true,
        'scrollX': true,
        'scrollY': false,
        "order": [
            [2, 'desc']
        ],
	    "columnDefs": [
	        { "orderable": false, "targets": [0, 1, 3, 4, 5, 6] }
	    ],
        'language': {
        	'searchPlaceholder': "Emp. Code / Name",
            'paginate': {
                'previous': "<i class='mdi mdi-chevron-left'>",
                'next': "<i class='mdi mdi-chevron-right'>"
            }
        },
        "drawCallback": function () {
            $('.dataTables_paginate > .pagination').addClass('pagination-rounded');
        },
        'processing': true,
        'serverSide': true,
        ajax: {
            'url': base_url + 'main.php?action=archived_employee', 
            'type': 'POST',
            'data': ''
        },
        'columns': [
            { data: 'srno' },
            { data: 'emp_code' },
            { data: 'date' },
            { data: 'name' },
            { data: 'phone' },
            { data: 'email' },
            { data: 'action' },
        ],
        "bDestroy": true
    });
}

function changeEmployeeStatus(status, code) {

	if (status == 0) {
		text = 'Are you sure to delete '+code+' employee again?';
	}else{
		text = 'Are you sure to activate '+code+' employee again?';
	}
    cuteAlert({
        type: "question",
        title: text,
        message: "Confirm Message",
        confirmText: "Yes",
        cancelText: "No"
    }).then((e)=>{
        if ( e == ("confirm")){
		    $.ajax({
            	url: base_url + 'main.php?action=change_status_this_employee', 
		        type: 'POST',
		        data: { code: code, status: status },
		        dataType: 'json',
		        success: function (data) {
					cuteToast({
					    title: data.message,
					    type: data.status,
					    message: data.message,
					    timer: 1500
					});
					activeEmp();
					archivedEmp();
		        }
		    });
        }
  	})
}


$("#addEditEmp").validate({
    rules : {
      	name  : { required: true, maxlength : 40 },
      	phone : { required: true, number : 1 },
      	email : { email : 1 },
  	},
	messages: {
	    name: {
	        required: "Enetr Name"
	    },
	    phone: {
	        required: "Enetr Phone No."
	    }
	},
    errorPlacement: function (error, element) {
        error.insertBefore(element);
    },
    submitHandler: function () {
	    cuteAlert({
	        type: "question",
	        title: "Are you sure to add new employee?",
	        message: "Confirm Message",
	        confirmText: "Yes",
	        cancelText: "No"
	    }).then((e)=>{
	        if ( e == ("confirm")){
	          	$('.formbtn').prop('disabled', true);
			    $.ajax({
            		url: base_url + 'main.php?action=add_edit_this_employee', 
			        type: 'POST',
			        data: $('#addEditEmp').serialize(),
			        dataType: 'json',
			        success: function (data) {
						cuteToast({
						    title: data.message,
						    type: data.status,
						    message: data.message,
						    timer: 1500
						});
			        	$('#exampleModal').modal('hide');
						activeEmp();
			          	$('.formbtn').prop('disabled', false);
			        },
			    });
	      		return false;
	        }
      	})


    }
});

function editEmployee(code) {
    $.ajax({
		url: base_url + 'main.php?action=get_this_employee', 
        type: 'POST',
        data: { code: code },
        dataType: 'json',
        success: function (data) {
			$('#name').val(data.name);
			$('#phone').val(data.phone_no);
			$('#email').val(data.email);
			$('#code').val(code);
        	$('#exampleModal').modal('show');
        },
    });
}
