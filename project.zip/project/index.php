<?php 
	include "config.php";
?>

<!DOCTYPE html>
<html lang="en">
	<head>
	  	<meta charset="utf-8">
	  	<meta http-equiv="x-ua-compatible" content="ie=edge">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Employee Management System</title>
  		<link rel="icon" href="<?php echo $base_url . 'assets/img/logo.png' ?>">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">		
	    <link href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css" rel="stylesheet" />
	    <link href="https://cdn.datatables.net/rowreorder/1.3.1/css/rowReorder.dataTables.min.css" rel="stylesheet" />
	    <link href="https://cdn.datatables.net/responsive/2.4.0/css/responsive.dataTables.min.css" rel="stylesheet" />
		<link href="<?php echo $base_url . 'assets/cute-alert.css'; ?>" rel="stylesheet" type="text/css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	</head>

	<style type="text/css">
		.nav-bg { box-shadow: 0px 0px 2px #858585; }
		.error { color: red; }
		.btn-primary,
		.btn-primary:hover,
		.btn-primary:focus,
		.btn-primary:active { background: #2e6165; border: none; box-shadow: none; }
	</style>

	<body>
		<nav class="nav-bg text-center">
			<a href="" title="Employee Management System">
				<img src="<?php echo $base_url . 'assets/img/logo.png' ?>" style="width: 100px;">
			</a>
		</nav>

		<div class="container">
			<button type="button" class="btn btn-primary mt-4" data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="(function(){$('.form-control').val('');})();"> Add New Employee </button>

			<section id="active_emp" class="mt-4">
				<div class="card">
					<div class="card-header">
						<h4 class="card-title">Active Employees</h4>
					</div>						
					<div class="card-body tableResponsiveScroll">
						<table class="table w-100" id="active_emp_table">
							<thead>
								<tr>
									<th>Sr. No.</th>
									<th>Employee Code</th>
									<th>Date</th>
									<th>Name</th>
									<th>Phone No.</th>
									<th>Email</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody></tbody>
						</table>
					</div>						
				</div>
			</section>

			<section id="archived_emp" class="mt-4 mb-5">
				<div class="card">
					<div class="card-header">
						<h4 class="card-title">Archived Employees</h4>
					</div>						
					<div class="card-body tableResponsiveScroll">
						<table class="table w-100" id="archived_emp_table">
							<thead>
								<tr>
									<th>Sr. No.</th>
									<th>Employee Code</th>
									<th>Date</th>
									<th>Name</th>
									<th>Phone No.</th>
									<th>Email</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody></tbody>
						</table>
					</div>						
				</div>				
			</section>
		</div>


		<!-- Modal -->
		<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog">
		    <form class="modal-content form" id="addEditEmp" >
		      <div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLabel">Add Employee</h5>
		        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		      </div>
		      <div class="modal-body">
		      	<div class="form-group">
		      		<label for="name" class="form-label">Name  <span class="text-danger">*</span></label>
    				<input type="text" class="form-control" id="name" name="name" maxlength='30'>
		      	</div>
		      	<div class="form-group mt-3">
		      		<label for="phone" class="form-label">Phone No. <span class="text-danger">*</span></label>
    				<input type="mobile" class="form-control" id="phone" name="phone" maxlength='10' minlength='10'>
		      	</div>
		      	<div class="form-group mt-3">
		      		<label for="email" class="form-label">Email </label>
    				<input type="email" class="form-control" id="email" name="email" maxlength='30'>
		      	</div>
    			<input type="hidden" class="form-control" id="code" name="code" maxlength='30' value="">
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
		        <button type="submit" class="btn btn-primary formbtn">Save</button>
		      </div>
		    </form>
		  </div>
		</div>
	</body>	
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	<script src="<?php echo $base_url . 'assets/jquery.validate.min.js'; ?>"></script>
	<script src="<?php echo $base_url . 'assets/cute-alert.css'; ?>"></script>
	<script src="<?php echo $base_url . 'assets/cute-alert.js'; ?>"></script>
 	<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
   	<script src="https://cdn.datatables.net/rowreorder/1.3.1/js/dataTables.rowReorder.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.4.0/js/dataTables.responsive.min.js"></script>
	<script src="<?php echo $base_url . 'assets/script.js'; ?>"></script>
</html>