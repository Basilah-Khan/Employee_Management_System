<?php 
	include 'config.php';
	date_default_timezone_set('Asia/Kolkata');
	$action = @$_GET['action'];
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	if ($action == 'active_employee') {
        $draw = isset($_POST['draw']) ? $_POST['draw'] : 0;
        $row = isset($_POST['start']) ? $_POST['start'] : 0;
        $rowperpage = isset($_POST['length']) ? $_POST['length'] : 10;
        $columnIndex = isset($_POST['order'][0]['column']) ? $_POST['order'][0]['column'] : '0';
        $columnName = isset($_POST['columns'][$columnIndex]['data']) ? $_POST['columns'][$columnIndex]['data'] : '';
        $columnSortOrder = isset($_POST['order'][0]['dir']) ? $_POST['order'][0]['dir'] : 'desc';
        $searchValue = isset($_POST['search']['value']) ? $_POST['search']['value'] : '';
        $queryAppend = '';
        if (!empty($searchValue)) {
            $queryAppend.= " AND (name LIKE '%" . $searchValue . "%' OR emp_code LIKE '%" . $searchValue . "%') ";
        }
		$query1 = $pdo->prepare("SELECT * FROM employee ");
		$query1->execute();
		$count = $query1->rowCount();
		if ($count > 0) {
       	 	$queryAppend .= "  ORDER BY created_date $columnSortOrder ";
			$query2 = $pdo->prepare("SELECT * FROM employee WHERE is_active = '1' $queryAppend limit $row, $rowperpage");
			$query2->execute();
			$data = $query2->fetchAll(PDO::FETCH_ASSOC);

			$response_array = array(); $srno = 1; 
			foreach ($data as $value) {
				$code = $value['emp_code'];
                $actionHTML = "<ul class='navbar-nav navbar-nav-right'>";
                $actionHTML .="<li class='nav-item nav-profile dropdown'>";
                $actionHTML .="<a  class='btn btn-secondary dropdown-toggle' href='#' role='button' id='dropdownMenuLink' data-bs-toggle='dropdown' aria-expanded='false'>Action</a>";
                $actionHTML .="<div class='dropdown-menu dropdown-menu-right navbar-dropdown' aria-labelledby='dropdownMenuLink' >";
                $actionHTML .="<button class='dropdown-item' onclick='editEmployee($code)'><i class='ti-marker-alt text-primary'></i> Edit </button>";
                $actionHTML .="<button class='dropdown-item' onclick='changeEmployeeStatus(0, $code)'><i class='ti-marker-alt text-primary'></i> Delete </button>";
                $actionHTML .="</div>";
                $actionHTML .="</li>";
                $actionHTML .="</ul>";

		        $arr = array(
		            "srno" => $srno, 
		            "emp_code" => $code,
		            "name" => $value['name'],
		            "date" => date('d-m-y', strtotime($value['created_date'])),
		            "phone" => '<a href="https://web.whatsapp.com/send/?phone=91'.$value['phone_no'].'&text&type=phone_number&app_absent=0" target="_block" style="color:#000;">'.$value['phone_no'].'</a>', 
		            "email" => '<a href="https://mail.google.com/mail/u/0/?view=cm&fs=1&to='.$value['email'].'&su=&body=&tf=1" target="_block" style="color:#000;">'.$value['email'].'</a>', 
		            "action" => $actionHTML, 
		        );
		        array_push($response_array, $arr);
		        $srno++;
			}

			if ($draw == 0) { $draw = $count; }
            $ArrayResponse = array("draw" => intval($draw), "iTotalRecords" => $count, "iTotalDisplayRecords" => $count, "aaData" => $response_array);
        } else{
        	$ArrayResponse = array("draw" => 1, "iTotalRecords" => 0, "iTotalDisplayRecords" => 0, "aaData" => array());
        }
        echo json_encode($ArrayResponse);
	}

	if ($action == 'archived_employee') {
        $draw = isset($_POST['draw']) ? $_POST['draw'] : 0;
        $row = isset($_POST['start']) ? $_POST['start'] : 0;
        $rowperpage = isset($_POST['length']) ? $_POST['length'] : 10;
        $columnIndex = isset($_POST['order'][0]['column']) ? $_POST['order'][0]['column'] : '0';
        $columnName = isset($_POST['columns'][$columnIndex]['data']) ? $_POST['columns'][$columnIndex]['data'] : '';
        $columnSortOrder = isset($_POST['order'][0]['dir']) ? $_POST['order'][0]['dir'] : 'desc';
        $searchValue = isset($_POST['search']['value']) ? $_POST['search']['value'] : '';
        $queryAppend = '';
        if (!empty($searchValue)) {
            $queryAppend.= " AND (name LIKE '%" . $searchValue . "%' OR emp_code LIKE '%" . $searchValue . "%') ";
        }

		$query1 = $pdo->prepare("SELECT * FROM employee ");
		$query1->execute();
		$count = $query1->rowCount();
		if ($count > 0) {
       	 	$queryAppend .= "  ORDER BY created_date $columnSortOrder ";
			$query2 = $pdo->prepare("SELECT * FROM employee WHERE is_active = '0' $queryAppend limit $row, $rowperpage");
			$query2->execute();
			$data = $query2->fetchAll(PDO::FETCH_ASSOC); 

			$response_array = array(); $srno = 1; 
			foreach ($data as $value) {
				$code = $value['emp_code'];
                $actionHTML ="<button class='btn btn-secondary' onclick='changeEmployeeStatus(1, $code)'><i class='ti-marker-alt text-primary'></i> Active </button>";

		        $arr = array(
		            "srno" => $srno, 
		            "emp_code" => $code,
		            "date" => date('d-m-y', strtotime($value['created_date'])),
		            "name" => $value['name'],
		            "phone" => '<a href="https://web.whatsapp.com/send/?phone=91'.$value['phone_no'].'&text&type=phone_number&app_absent=0" target="_block" style="color:#000;">'.$value['phone_no'].'</a>', 
		            "email" => '<a href="https://mail.google.com/mail/u/0/?view=cm&fs=1&to='.$value['email'].'&su=&body=&tf=1" target="_block" style="color:#000;">'.$value['email'].'</a>', 
		            "action" => $actionHTML, 
		        );
		        array_push($response_array, $arr);
		        $srno++;
			}

			if ($draw == 0) { $draw = $count; }
            $ArrayResponse = array("draw" => intval($draw), "iTotalRecords" => $count, "iTotalDisplayRecords" => $count, "aaData" => $response_array);
        } else {
            $ArrayResponse = array("draw" => 1, "iTotalRecords" => 0, "iTotalDisplayRecords" => 0, "aaData" => array());
        }
        echo json_encode($ArrayResponse);
	}

	if ($action == 'change_status_this_employee') {
		$code = $_POST['code'];
		$status = $_POST['status'];
		$query = $pdo->prepare("UPDATE employee SET is_active='$status' WHERE emp_code = '$code' ");
		if ($query->execute()) {
			if ($status == 0) {
				$message = 'Employee Deleted';
			}else{
				$message = 'Employee Activated';
			}
            $ArrayResponse = array("message" => $message, "status" => 'success');
        } else {
            $ArrayResponse = array("message" => 'Try again later', "status" => 'error');
        }
        echo json_encode($ArrayResponse);
	}

	if ($action == 'add_edit_this_employee') {
		$code     = $_POST['code'];
		$name     = $_POST['name'];
		$phone_no = $_POST['phone'];
		$email    = isset($_POST['email']) ? $_POST['email'] : NULL;
		if ($code == '') {
			$code 	  = rand(10000,99999);
			$date 	  = date('Y-m-d H:i:s');
			$query = $pdo->prepare("INSERT INTO employee( created_date, emp_code, name, phone_no, email ) VALUES ( :created_date, :emp_code, :name, :phone_no, :email )");
			$query->bindParam(':created_date', $date);
			$query->bindParam(':emp_code', $code);
			$query->bindParam(':name', $name);
			$query->bindParam(':phone_no', $phone_no);
			$query->bindParam(':email', $email);
			if ($query->execute()) {
	            $ArrayResponse = array("message" => 'New Employee Added', "status" => 'success');
	        } else {
	            $ArrayResponse = array("message" => 'Try again later', "status" => 'error');
	        }
	    }else{

			$query = $pdo->prepare("UPDATE employee SET name='$name', phone_no='$phone_no', email='$email' WHERE emp_code = '$code' ");
			if ($query->execute()) {
	            $ArrayResponse = array("message" => 'Employee Updated', "status" => 'success');
	        } else {
	            $ArrayResponse = array("message" => 'Try again later', "status" => 'error');
	        }
	    }

        echo json_encode($ArrayResponse);
	}

	if ($action == 'get_this_employee') {
		$code   = $_POST['code'];
		$query = $pdo->prepare("SELECT name, phone_no, email FROM employee WHERE emp_code = '$code' ");
		$query->execute();
		$count = $query->rowCount();
		if ($count > 0) {
			$ArrayResponse = $query->fetchAll(PDO::FETCH_ASSOC)[0];
        } else {
            $ArrayResponse = array();
        }
        echo json_encode($ArrayResponse);
	}

	if ($action == 'edit_this_employee') {
		$code   = $_POST['code'];
		$name   = $_POST['name'];
		$phone  = $_POST['phone'];
		$email  = $_POST['email'];
        echo json_encode($ArrayResponse);
	}

?>